package me.zoulei.frontend.node;

/**
 * 
* @author zoulei 
* @date 2023年9月28日 下午4:51:50 
* @description 属性接口
 */
public interface Attr {

	String toString(String tabStr, boolean isaddBlank);

}
