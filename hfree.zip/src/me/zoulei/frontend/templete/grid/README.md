# table模板。加载模板后根据配置信息生成最终的table对象。
下拉框或弹出框的设置
1、表单控件用ep-select或epl-public-window-edit
2、实体类代码字段用HYField
3、表格显示中文转换
