package me.zoulei.ui.components;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import dm.jdbc.util.StringUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import me.zoulei.Constants;
import me.zoulei.MainApp;
import me.zoulei.backend.jdbc.datasource.DataSource;
import me.zoulei.backend.jdbc.utils.CommQuery;
import me.zoulei.backend.templete.grid.TableMetaDataConfig;
import me.zoulei.gencode.Gencode;
import me.zoulei.ui.components.south.FlowComponentCenter;
import me.zoulei.ui.components.south.FlowSearchComponentNorth;
import me.zoulei.ui.frame.AutoCompletion;

/**
 * 2023年9月14日11:30:15  zoulei
 * 用于搜索数据库表的组件， 设置表后可以加载表格参数配置组件。  查询模式和表名 oracle和达梦，mysql
 * 2023年10月24日10:05:44 增加mysql类型
 */
public class SearchComponent {

	Item[] items;
	String[] items2 = new String[] {"sadsa","dsf","fsdfg","dsadsfx"};
	
	GridComponent grid;
	List<Component> removeComponents = new ArrayList<Component>();
	public void removeAll() {
		//第一次进来没渲染，不需要移除。 
		if(removeComponents.size()>0) {
			removeComponents.forEach(c->{
				MainApp.north.remove(c);
			});
			if(MainApp.south != null) {
				MainApp.mainFrame.remove(MainApp.south);
				MainApp.south = null;
			}
			MainApp.mainFrame.remove(this.grid.getEditorGrid());
			MainApp.mainFrame.getContentPane().repaint();
		}
		
	}
	
	Font font = new Font("宋体", Font.PLAIN, 18);
	
	public void setComp() {
		//初始化代码类别项
		this.initCodeType();
		//模式列表
		this.searchOwner();
		
		//表格组件
		this.grid = new GridComponent();
		
		//模式表名选择 放到北边的中间
		JPanel north2 = new JPanel();
		MainApp.north.add(north2,BorderLayout.CENTER);
		removeComponents.add(north2);
		
		JLabel  dslabel= new JLabel("选择模式: ", JLabel.LEFT);
		north2.add(dslabel);
		dslabel.setFont(font);
		
		/*
		dslabel= new JLabel("表格的属性设置: ", JLabel.LEFT);
		dslabel.setFont(new Font("宋体", Font.PLAIN, 20));
		north2.add(dslabel);
		*/
		
		//模式名下拉
		JComboBox<String> cbx2 = new JComboBox<String>(items2);
		
		JScrollPane msmscr = new JScrollPane(cbx2);
		north2.add(msmscr);
		msmscr.setBorder(MainApp.lineBorder);
		//cbx2.setEditable(true);
		cbx2.setSelectedItem("HY_GBGL_ZZGB");
		cbx2.setPreferredSize(new Dimension(200, 35));
		cbx2.setFont(font);
		
		//表名下拉
		search((String) cbx2.getSelectedItem());
		
		
		dslabel= new JLabel("输入表名: ", JLabel.CENTER);
		north2.add(dslabel);
		dslabel.setFont(font);
		
		JComboBox<Item> cbx = new JComboBox<Item>(items);
		//设置下拉最多显示的选项
		cbx.setMaximumRowCount(30);
		cbx.setPreferredSize(new Dimension(1100, 35));
		cbx.setFont(font);
		
		//生成数据库配置及代码按钮
		JButton genCodeBtn = new JButton("生成代码");
		genCodeBtn.setFont(font);
		genCodeBtn.setPreferredSize(new Dimension(90, 35));
		//选择模式后事件  查询表名，将选择表名的下拉框选项重新设置
		cbx2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				search((String) cbx2.getSelectedItem());
				cbx.removeAllItems();
				for (Item item : items) {
					cbx.addItem(item);
	            }
				
				//直接显示下拉选框
				//cbx.setPopupVisible(true);
			}
		});
		JScrollPane controlPanel = new JScrollPane(cbx);
		north2.add(controlPanel);
		//下拉框
		controlPanel.setBorder(MainApp.lineBorder);
		//实现搜索
		AutoCompletion.enable(cbx);
		//cbx.setEnabled(false);
        //cbx.setPopupVisible(true);
		
		
		
		
		//选择表名事件 选择后加载表格
		cbx.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Item item = (Item) cbx.getSelectedItem();
				if(item!=null) {
					grid.setComp(item.getKey(),(String) cbx2.getSelectedItem());
				}
			}
		});
		//第一次默认加载表
		Item item = (Item) cbx.getSelectedItem();
		if(item!=null) {
			grid.setComp(item.getKey(),(String) cbx2.getSelectedItem());
		}
		
		
		north2.add(genCodeBtn);
		genCodeBtn.addActionListener(new ActionListener() {
	         public void actionPerformed(ActionEvent e) {     
	             //生成配置
	        	 List<HashMap<String, String>> tmd = grid.editorGrid.genTableMetaData();
	        	 Item item = (Item) cbx.getSelectedItem();
	        	 try {
	        		 //生成代码
					new Gencode().gencode(new TableMetaDataConfig(item.getKey(),item.getValue(), tmd, grid.editorGrid));
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(MainApp.mainFrame, e1.getMessage());    
					e1.printStackTrace();
				}
	            
	         }
	      });
		
		genCodeBtn.setBorder(MainApp.lineBorder);
		
		
		
		JCheckBox flowCheckBox = new JCheckBox("流程配置",false);
		north2.add(flowCheckBox);
		flowCheckBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                	//附表设置
					FlowSearchComponentNorth flowSearchComponentNorth = new FlowSearchComponentNorth();
					if(MainApp.debugbBorder!=null) {
						flowSearchComponentNorth.setBorder(MainApp.debugbBorder);
					}
					//添加South面板
					MainApp.addSouth();
					MainApp.south.add(flowSearchComponentNorth,BorderLayout.NORTH);
					//流程模型配置
				    FlowComponentCenter fc = new FlowComponentCenter();
				    if(MainApp.debugbBorder!=null) {
				    	fc.setBorder(MainApp.debugbBorder);
				    }
				    MainApp.south.add(fc,BorderLayout.CENTER);
				    MainApp.mainFrame.setSize(MainApp.MAIN_WIDTH, 1000);
                } else {
                	//移除South面板
                	MainApp.mainFrame.remove(MainApp.south);
                	MainApp.mainFrame.setSize(MainApp.MAIN_WIDTH, MainApp.MAIN_HEIGHT);
                	
                }
                //组件发生变化，更新ui
                MainApp.south.updateUI();
                
            }
        });
		
	}
	//查询表
	public void search(String sch) {
		if(StringUtil.isEmpty(sch)) {
			items = new Item[] {};
			//return;
		}
		String sql = "select t.table_name,c.COMMENTS TABLE_COMMENT from All_TABLES t,SYS.ALL_TAB_COMMENTS c where t.TABLE_NAME=c.TABLE_NAME and t.owner = c.owner and t.owner = '"+sch.toUpperCase()+"' order by table_name ";
		if(DataSource.DBType.equalsIgnoreCase("mysql")) {
			sql = "SELECT TABLE_NAME,TABLE_COMMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA='"+sch.toUpperCase()+"' and TABLE_COMMENT!='VIEW'  order by table_name" ;
		}
		
		CommQuery cq = new CommQuery();
		try {
			List<HashMap<String, String>> list = cq.getListBySQL2(sql);
			items = new Item[list.size()];
			for(int i=0;i<list.size();i++) {
				items[i] = new Item(list.get(i).get("table_name"),list.get(i).get("table_comment"));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(MainApp.mainFrame, e.getMessage());    
			e.printStackTrace();
		}
	}
	//查询模式
	public void searchOwner() {
		
		String sql = "select distinct owner schema_name from ALL_TABLES ";
		if(DataSource.DBType.equalsIgnoreCase("mysql")) {
			sql = "SHOW DATABASES";
		}
		CommQuery cq = new CommQuery();
		try {
			List<HashMap<String, String>> list = cq.getListBySQL2(sql);
			items2 = new String[list.size()];
			for(int i=0;i<list.size();i++) {
				items2[i] = list.get(i).get("schema_name").toUpperCase();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 表名选择下拉框
	 */
	@Data
	@AllArgsConstructor
	public class Item {
		private String key;
		private String value;
		public String toString(){
			return key + "("+(value==null?"":value)+")";
		}
	}
	
	
	
	//选择codetype的下拉框选项
	private void initCodeType() {
		if(Constants.codetype_items!=null) return;
		CommQuery cq = new CommQuery();
		try {
			List<HashMap<String, String>> list = cq.getListBySQL2(Constants.CODE_VALUE_SQL);
			String[] items = new String[list.size()*2+2];
			//文本、公务员常用时间控件、codetype
			int i=0;
			items[i++] = "文本";
			items[i++] = "公务员常用时间控件";
			for (int j = 0; j < list.size(); j++) {
				HashMap<String, String> m = list.get(j);
				String codetype = m.get("code_type");
				String typename = m.get("type_name");
				items[i++] = codetype+":下拉选:"+typename;
				items[i++] = codetype+":弹出框:"+typename;
			}
			Constants.codetype_items = items;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
}
