package com.insigma.business.components.hyfield;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSONObject;
import com.insigma.business.ZZGBGL.ZZGBGL_JGXX.ZZGBGL_JGXX003.dto.B216Dto;
import com.insigma.business.components.hyfield.HYBeanUtil;
import com.insigma.business.entity.B216;
import com.insigma.framework.exception.AppException;
import com.insigma.odin.framework.datasource.SQLProcessor;
import com.insigma.odin.framework.persistence.HBSession;

/**
 * 简单分页查询和初始化代码
 * @ClassName: PageDao
 * @Desc: TODO
 * @author zoulei
 * @date 2024年5月10日 上午10:16:22
 */
public class PageDao {

	@Autowired
	private HBSession session;

	
	@Autowired
	HYBeanUtil hybean;
	
	//获取代码
	public List<Map<String, Object>> initCodeType(String codeType, String filter) {
		
		SQLProcessor sqlPro = new SQLProcessor(session, PageDao.class);
		Map<String,Object> params = new HashMap<>();
		params.put("codeType", codeType);
		params.put("filter", filter);
		String sql = sqlPro.getSQLFromXml("initCodeType", params);
		return session.queryForList(sql);
	}
	
	/**
	 * 简单分页查询
	 * @param pageData   
	 * 说明：pageData需包含pageInfo:{currentPage:1,pageSize:50}信息
	 * @param sql
	 * @return 分页查询的sql
	 */
	public String getPageSql(JSONObject pageData,String sql) {
	
		SQLProcessor sqlPro = new SQLProcessor(session, PageDao.class);
		
		Map<String,Object> params = new HashMap<>();
		//分页信息
		JSONObject pageInfo = pageData.getJSONObject("pageInfo");
		int currentPage = pageInfo.getIntValue("currentPage");
		int pageSize = pageInfo.getIntValue("pageSize");
		int start = (currentPage-1)*pageSize;
		//总数
		String countsql = "select count(*) from (" + sql + ") c";
		int total = session.queryForInteger(countsql);
		pageInfo.put("total", total);
		params.put("end", start + pageSize);
		params.put("start", start + 1);
		params.put("startM", start);
		params.put("pageSize", pageSize);
		params.put("sql", sql);
		String getPageSql = sqlPro.getSQLFromXml("getPageSql", params);
		return getPageSql;
	}
	

}
